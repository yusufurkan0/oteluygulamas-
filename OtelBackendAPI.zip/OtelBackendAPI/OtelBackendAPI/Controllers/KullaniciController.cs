﻿using Microsoft.AspNetCore.Mvc;
using OtelBackendAPI.Models;
using System.Linq;

namespace OtelBackendAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KullaniciController : ControllerBase
    {
        [HttpPost("kayit")]
        public IActionResult KayitOl([FromBody] Kullanici yeniKullanici)
        {
            using (var db = new OtelContext())
            {
                if (db.Kullanicilar.Any(k => k.Email == yeniKullanici.Email))
                    return BadRequest(new { mesaj = "Bu e-posta zaten sistemde kayıtlı!" });

                db.Kullanicilar.Add(yeniKullanici);
                db.SaveChanges();
                return Ok(new { mesaj = "Kayıt başarıyla oluşturuldu!" });
            }
        }

        [HttpPost("giris")]
        public IActionResult GirisYap([FromBody] Kullanici girisBilgisi)
        {
            using (var db = new OtelContext())
            {
                var kullanici = db.Kullanicilar.FirstOrDefault(k => k.Email == girisBilgisi.Email && k.Sifre == girisBilgisi.Sifre);
                if (kullanici != null)
                {
                    string gercekAdSoyad = kullanici.Ad + " " + kullanici.Soyad;
                    var doluOda = db.Odalar.FirstOrDefault(o => o.DoluMu && o.MusteriAdi == gercekAdSoyad);
                    string kayitliOdaNo = doluOda != null ? doluOda.OdaNo : "";

                    return Ok(new { mesaj = "Giriş Başarılı", adSoyad = gercekAdSoyad, email = kullanici.Email, telefon = kullanici.Telefon, odaNo = kayitliOdaNo });
                }
                return BadRequest(new { mesaj = "Şifre yanlış veya böyle bir kayıt yok!" });
            }
        }

        // 👑 YÖNETİCİ YETKİLERİ 👑

        [HttpGet("liste")]
        public IActionResult TumKullanicilariGetir()
        {
            using (var db = new OtelContext())
            {
                return Ok(db.Kullanicilar.ToList());
            }
        }

        [HttpPost("guncelle")]
        public IActionResult KullaniciGuncelle([FromBody] Kullanici guncelBilgi)
        {
            using (var db = new OtelContext())
            {
                var user = db.Kullanicilar.FirstOrDefault(k => k.Id == guncelBilgi.Id);
                if (user != null)
                {
                    user.Ad = guncelBilgi.Ad;
                    user.Soyad = guncelBilgi.Soyad;
                    user.Telefon = guncelBilgi.Telefon;
                    user.Email = guncelBilgi.Email;
                    user.Sifre = guncelBilgi.Sifre;
                    db.SaveChanges();
                    return Ok(new { mesaj = "Kullanıcı başarıyla güncellendi!" });
                }
                return BadRequest(new { mesaj = "Kullanıcı bulunamadı!" });
            }
        }

        [HttpPost("sil")]
        public IActionResult KullaniciSil([FromBody] Kullanici silinecekKullanici)
        {
            using (var db = new OtelContext())
            {
                var user = db.Kullanicilar.FirstOrDefault(k => k.Id == silinecekKullanici.Id);
                if (user != null)
                {
                    db.Kullanicilar.Remove(user);
                    db.SaveChanges();
                    return Ok(new { mesaj = "Kullanıcı sistemden tamamen silindi!" });
                }
                return BadRequest(new { mesaj = "Silinecek kullanıcı bulunamadı!" });
            }
        }
    }
}