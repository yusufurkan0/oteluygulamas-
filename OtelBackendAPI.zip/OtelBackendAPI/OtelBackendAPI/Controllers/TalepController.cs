﻿using Microsoft.AspNetCore.Mvc;
using OtelBackendAPI.Models;
using System;
using System.Linq;

namespace OtelBackendAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TalepController : ControllerBase
    {
        [HttpGet("odalar")]
        public IActionResult OdalariGetir()
        {
            using (var db = new OtelContext()) { return Ok(db.Odalar.ToList()); }
        }

        [HttpPost("odasec")]
        public IActionResult OdaRezerveEt([FromBody] Oda gelenOda)
        {
            using (var db = new OtelContext())
            {
                var oda = db.Odalar.FirstOrDefault(o => o.OdaNo == gelenOda.OdaNo);
                if (oda != null && !oda.DoluMu)
                {
                    oda.DoluMu = true; oda.MusteriAdi = gelenOda.MusteriAdi; oda.GeceSayisi = gelenOda.GeceSayisi;
                    db.SaveChanges(); // SQL'İ GÜNCELLE!
                    return Ok(new { mesaj = "Oda başarıyla rezerve edildi." });
                }
                return BadRequest(new { mesaj = "Bu oda zaten dolu veya bulunamadı!" });
            }
        }

        [HttpPost("odabosalt")]
        public IActionResult OdaBosalt([FromBody] Oda gelenOda)
        {
            using (var db = new OtelContext())
            {
                var oda = db.Odalar.FirstOrDefault(o => o.OdaNo == gelenOda.OdaNo);
                if (oda != null && oda.DoluMu)
                {
                    oda.DoluMu = false; oda.MusteriAdi = null; oda.GeceSayisi = null;
                    db.SaveChanges(); // SQL'İ GÜNCELLE!
                    return Ok(new { mesaj = $"{oda.OdaNo} numaralı oda başarıyla boşaltıldı." });
                }
                return BadRequest(new { mesaj = "Bu oda zaten boş!" });
            }
        }

        [HttpPost]
        public IActionResult YeniTalepGonder([FromBody] Talep gelenSiparis)
        {
            using (var db = new OtelContext())
            {
                gelenSiparis.Tarih = DateTime.Now.ToString("HH:mm:ss");
                db.Talepler.Add(gelenSiparis);
                db.SaveChanges();
                return Ok(new { mesaj = "Talep resepsiyona ulaştı!" });
            }
        }

        [HttpGet("panel")]
        public ContentResult ResepsiyonPaneli()
        {
            using (var db = new OtelContext())
            {
                string html = @"<html><head><meta charset='utf-8'><meta http-equiv='refresh' content='3'><title>Otel Yönetim Paneli</title><style>body { font-family: 'Segoe UI', sans-serif; background-color: #f4f7f6; padding: 20px; } h2 { color: #2c3e50; border-bottom: 2px solid #009688; padding-bottom: 5px;} table { width: 100%; border-collapse: collapse; background: white; margin-bottom: 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.2); } th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; } th { background-color: #009688; color: white; } .dolu { color: white; background-color: #F44336; padding: 4px 8px; border-radius: 4px; font-weight: bold;} .bos { color: white; background-color: #4CAF50; padding: 4px 8px; border-radius: 4px; font-weight: bold;}</style></head><body><h1>🛎️ Otel Resepsiyon Ana Ekranı</h1><h2>🏨 Güncel Oda Durumları</h2><table><tr><th>Kat Bilgisi</th><th>Oda No</th><th>Durum</th><th>Müşteri Adı</th><th>Kalacağı Gece</th></tr>";
                foreach (var oda in db.Odalar.ToList())
                {
                    string durumHtml = oda.DoluMu ? "<span class='dolu'>DOLU</span>" : "<span class='bos'>BOŞ</span>";
                    string musteri = oda.DoluMu ? oda.MusteriAdi : "-";
                    string gece = oda.DoluMu ? oda.GeceSayisi + " Gece" : "-";
                    html += $"<tr><td>{oda.KatInfo}</td><td><strong>{oda.OdaNo}</strong></td><td>{durumHtml}</td><td>{musteri}</td><td>{gece}</td></tr>";
                }
                html += @"</table><h2>💬 Canlı Oda Servisi & Temizlik Talepleri</h2><table><tr><th>Saat</th><th>Oda No</th><th>Müşteri Adı</th><th>Telefon Numarası</th><th>Mail Adresi</th><th>Talep Tipi</th><th>Ek Not</th></tr>";

                var tersTalepler = db.Talepler.ToList();
                tersTalepler.Reverse();
                foreach (var talep in tersTalepler)
                {
                    html += $"<tr><td>{talep.Tarih}</td><td><strong>{talep.OdaNo}</strong></td><td>{talep.AdSoyad}</td><td style='color:#E91E63; font-weight:bold;'>{talep.Telefon}</td><td style='color:#2196F3;'>{talep.Email}</td><td style='color:#FF9800; font-weight:bold;'>{talep.TalepTipi}</td><td>{talep.EkNot}</td></tr>";
                }
                html += @"</table></body></html>";
                return Content(html, "text/html", System.Text.Encoding.UTF8);
            }
        }
    }
}