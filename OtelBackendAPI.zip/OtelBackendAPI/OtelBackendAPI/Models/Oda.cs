﻿using System.ComponentModel.DataAnnotations;
namespace OtelBackendAPI.Models
{
    public class Oda
    {
        [Key] public int Id { get; set; } // SQL İÇİN ŞART!
        public string KatInfo { get; set; }
        public string OdaNo { get; set; }
        public bool DoluMu { get; set; }
        public string MusteriAdi { get; set; }
        public string GeceSayisi { get; set; }
    }
}