﻿using Microsoft.EntityFrameworkCore;

namespace OtelBackendAPI.Models
{
    public class OtelContext : DbContext
    {
        public DbSet<Kullanici> Kullanicilar { get; set; }
        public DbSet<Oda> Odalar { get; set; }
        public DbSet<Talep> Talepler { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=otelveritabani.db");
        }

        public OtelContext()
        {
            bool yeniOlusturuldu = Database.EnsureCreated();
            if (yeniOlusturuldu)
            {
                Odalar.AddRange(
                    new Oda { KatInfo = "1. Kat (Tek Kişilik)", OdaNo = "101", DoluMu = false, MusteriAdi = "", GeceSayisi = "" },
                    new Oda { KatInfo = "1. Kat (Tek Kişilik)", OdaNo = "102", DoluMu = false, MusteriAdi = "", GeceSayisi = "" },
                    new Oda { KatInfo = "1. Kat (Tek Kişilik)", OdaNo = "103", DoluMu = false, MusteriAdi = "", GeceSayisi = "" },
                    new Oda { KatInfo = "2. Kat (Çift Kişilik)", OdaNo = "201", DoluMu = false, MusteriAdi = "", GeceSayisi = "" },
                    new Oda { KatInfo = "2. Kat (Çift Kişilik)", OdaNo = "202", DoluMu = false, MusteriAdi = "", GeceSayisi = "" },
                    new Oda { KatInfo = "2. Kat (Çift Kişilik)", OdaNo = "203", DoluMu = false, MusteriAdi = "", GeceSayisi = "" },
                    new Oda { KatInfo = "3. Kat (Aile 3-4 Kişi)", OdaNo = "301", DoluMu = false, MusteriAdi = "", GeceSayisi = "" },
                    new Oda { KatInfo = "3. Kat (Aile 3-4 Kişi)", OdaNo = "302", DoluMu = false, MusteriAdi = "", GeceSayisi = "" },
                    new Oda { KatInfo = "3. Kat (Aile 3-4 Kişi)", OdaNo = "303", DoluMu = false, MusteriAdi = "", GeceSayisi = "" }
                );
                SaveChanges();
            }
        }
    }
}