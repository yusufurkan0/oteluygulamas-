﻿using System.ComponentModel.DataAnnotations;
namespace OtelBackendAPI.Models
{
    public class Kullanici
    {
        [Key] public int Id { get; set; } // SQL İÇİN ŞART!
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string Email { get; set; }
        public string Sifre { get; set; }
        public string Telefon { get; set; }
    }
}