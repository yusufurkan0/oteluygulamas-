﻿using System.ComponentModel.DataAnnotations;
namespace OtelBackendAPI.Models
{
    public class Talep
    {
        [Key] public int Id { get; set; } // SQL İÇİN ŞART!
        public string OdaNo { get; set; }
        public string AdSoyad { get; set; }
        public string Email { get; set; }
        public string Telefon { get; set; }
        public string TalepTipi { get; set; }
        public string EkNot { get; set; }
        public string Tarih { get; set; }
    }
}